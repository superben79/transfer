SSLClient Java tool readme.txt


This tool can be used to connect to an https port and perform an SSL 
handshake.  The program will also extract the SSL Server's certificate 
chain (public certificate and any CA certificates handed out), and write 
each to the local file system.

To compile/run the SSLClient class:

(1) you must have the <IS_root>/client.jar in the system CLASSPATH. 

(2) must use a JDK version 1.2.x or 1.3.x 

(3) to run, just type:

%java SSLClient <host> <port>

Example:

java SSLClient amazon.com 443


.....will print out a summary of the handshake, and write certificate files 
locally with names like peer0.der, peer1.der, etc.

